/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.lab2;

import java.util.*;

public class CarShowroom {

    private ArrayList<Brand> brands = new ArrayList<>();
    private ArrayList<Car> cars = new ArrayList<>();
    private Scanner sc = new Scanner(System.in);
//lít
    public void listAllBrands() {
        if (brands.isEmpty()) {
            System.out.println("No brands.");
        } else {
            for (Brand b : brands) {
                System.out.println(b);
            }
        }
    }

//Add brand
    public void addBrand() {
        System.out.print("Enter brand ID: ");
        String id = sc.nextLine();
        System.out.print("Enter brand name: ");
        String name = sc.nextLine();
        System.out.print("Enter sound brand: ");
        String sound = sc.nextLine();
        System.out.print("Enter price (billion): ");
        double price = Double.parseDouble(sc.nextLine());

        brands.add(new Brand(id, name, sound, price));
        System.out.println("Brand added.");
    }

//Search brand by ID
    public Brand searchBrandByID(String id) {
        for (Brand b : brands) {
            if (b.getBrandID().equalsIgnoreCase(id)) {
                return b;
            }
        }
        return null;
    }

//Update brand
    public void updateBrand() {
        System.out.print("Enter brand ID to update: ");
        String id = sc.nextLine();
        Brand b = searchBrandByID(id);
        if (b == null) {
            System.out.println("Brand not found.");
            return;
        }
        System.out.print("New brand name: ");
        b.setBrandName(sc.nextLine());
        System.out.print("New sound brand: ");
        b.setSoundBrand(sc.nextLine());
        System.out.print("New price: ");
        b.setPrice(Double.parseDouble(sc.nextLine()));
        System.out.println("Brand updated.");
    }

//Líst all car
    public void listAllCars() {
        if (cars.isEmpty()) {
            System.out.println("No cars.");
        } else {
            for (Car c : cars) {
                System.out.println(c);
            }
        }
    }

//Add car
    public void addCar() {
        System.out.print("Enter car ID: ");
        String carID = sc.nextLine();
        System.out.print("Enter brand ID: ");
        String brandID = sc.nextLine();
        if (searchBrandByID(brandID) == null) {
            System.out.println("Brand not found!");
            return;
        }
        System.out.print("Enter color: ");
        String color = sc.nextLine();
        System.out.print("Enter frame ID (F00000): ");
        String frame = sc.nextLine();
        System.out.print("Enter engine ID (E00000): ");
        String engine = sc.nextLine();

        cars.add(new Car(carID, brandID, color, frame, engine));
        System.out.println("Car added.");
    }

//Remove car by ID
    public void removeCarByID() {
        System.out.print("Enter car ID to remove: ");
        String id = sc.nextLine();
        cars.removeIf(c -> c.getCarID().equalsIgnoreCase(id));
        System.out.println("Removed (if existed).");
    }
}
