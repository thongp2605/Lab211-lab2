/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.lab2;

/**
 *
 * @author ASUS
 */
public class Car {

    private String carID;
    private String brandID;
    private String color;
    private String frameID;
    private String engineID;

    public Car(String carID, String brandID, String color, String frameID, String engineID) {
        this.carID = carID;
        this.brandID = brandID;
        this.color = color;
        this.frameID = frameID;
        this.engineID = engineID;
    }

    public String getCarID() {
        return carID;
    }

    public String getBrandID() {
        return brandID;
    }

    public String getColor() {
        return color;
    }

    public String getFrameID() {
        return frameID;
    }

    public String getEngineID() {
        return engineID;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setFrameID(String frameID) {
        this.frameID = frameID;
    }

    public void setEngineID(String engineID) {
        this.engineID = engineID;
    }

    @Override
    public String toString() {
        return carID + " | " + brandID + " | " + color + " | " + frameID + " | " + engineID;
    }
}
