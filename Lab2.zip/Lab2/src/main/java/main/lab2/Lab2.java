/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package main.lab2;

import java.util.Scanner;

public class Lab2 {

    public static void main(String[] args) {
        CarShowroom showroom = new CarShowroom();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Car Showroom Management ---");
            System.out.println("1. List all brands");
            System.out.println("2. Add a brand");
            System.out.println("3. Update a brand");
            System.out.println("4. List all cars");
            System.out.println("5. Add a car");
            System.out.println("6. Remove a car");
            System.out.println("0. Quit");
            System.out.print("Your choice: ");
            choice = Integer.parseInt(sc.nextLine());

            switch (choice) {
                case 1:
                    showroom.listAllBrands();
                    break;
                case 2:
                    showroom.addBrand();
                    break;
                case 3:
                    showroom.updateBrand();
                    break;
                case 4:
                    showroom.listAllCars();
                    break;
                case 5:
                    showroom.addCar();
                    break;
                case 6:
                    showroom.removeCarByID();
                    break;
                case 0:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid!");
            }
        } while (choice != 0);
    }
}
